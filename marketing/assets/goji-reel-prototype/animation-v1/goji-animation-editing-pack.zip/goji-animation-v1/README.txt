Source editing pack: native animated clips, five sound stems, effects-only mix, exact prompts and local scripts.
The 20-second MP4 masters and mobile preview are available on GitHub:
https://github.com/gojiphysio/goji/blob/codex/goji-reel-mobile-handoff/marketing/assets/goji-reel-prototype/animation-v1/README.md
